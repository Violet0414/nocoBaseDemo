"use client";

import React from "react";
import { type BaseKey, useListButton } from "@refinedev/core";
import { Button } from "@/components/ui/button";
import { List } from "lucide-react";

type ListButtonProps = {
  /**
   * Resource name for API data interactions. `identifier` of the resource can be used instead of the `name` of the resource.
   * @default Inferred resource name from the route
   */
  resource?: BaseKey;
  /**
   * Access Control configuration for the button
   * @default `{ enabled: true, hideIfUnauthorized: false }`
   */
  accessControl?: {
    enabled?: boolean;
    hideIfUnauthorized?: boolean;
  };
  /**
   * `meta` property is used when creating the URL for the related action and path.
   */
  meta?: Record<string, unknown>;
} & React.ComponentProps<typeof Button>;

export const ListButton = React.forwardRef<
  React.ComponentRef<typeof Button>,
  ListButtonProps
>(({ resource, accessControl, meta, children, onClick, ...rest }, ref) => {
  const { hidden, disabled, LinkComponent, to, label } = useListButton({
    resource,
    accessControl,
    meta,
  });

  const isDisabled = disabled || rest.disabled;
  const isHidden = hidden || rest.hidden;

  if (isHidden) return null;

  return (
    <Button
      {...rest}
      ref={ref}
      disabled={isDisabled}
      render={<LinkComponent to={to} replace={false} />}
      onClick={(event) => {
        if (isDisabled) {
          event.preventDefault();
          return;
        }
        if (onClick) {
          event.preventDefault();
          onClick(event);
        }
      }}
    >
      {children ?? (
        <div className="flex items-center gap-2 font-semibold">
          <List className="w-4 h-4" />
          <span>{label}</span>
        </div>
      )}
    </Button>
  );
});

ListButton.displayName = "ListButton";
